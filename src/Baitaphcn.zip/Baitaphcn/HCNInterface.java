package Baitaphcn;


public interface HCNInterface
    {
        public abstract int ChuviHCN();
        public abstract int DientichHCN();
        public abstract int getChieuDai();
        public abstract int getChieuRong();
        public abstract void setDaiRong(int cd, int cr);
    }

