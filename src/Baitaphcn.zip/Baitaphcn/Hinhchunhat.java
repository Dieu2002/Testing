package Baitaphcn;

import java.util.Scanner;
public class Hinhchunhat implements HCNInterface
{
    private int chieudai;
    private int chieurong;
    public int ChuviHCN()
    {
        return (chieudai + chieurong) /2;
    }
    public int DientichHCN()
    {
        return chieudai*chieurong;
    }
    public int getChieuDai( )
    {
        return chieudai;
    }
    public int getChieuRong()
    {
        return chieurong;
    }
    public void setDaiRong(int cd, int cr)
    {
        this.chieudai=cd;
        this.chieurong=cr;
    }
}