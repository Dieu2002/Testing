package Baitaphcn;

import java.util.Scanner;

public class HCNtest extends Hinhchunhat
{
    public static void main(String[] args)
    {
        int i,j,cd,cr;
        System.out.print("Nhập số lượng hình chữ nhật:");
        Scanner q = new Scanner(System.in);
        int n = q.nextInt();
        HCNtest[] hcn = new HCNtest[n];
        for(i=1;i<=n;i++)
        {
            System.out.println("Nhập thông tin HCN thứ  "+i);
            System.out.print("Nhập chiều dài:");
            cd= q.nextInt();
            System.out.print("Nhập chiều rộng:");
            cr= q.nextInt();
            hcn[i].setDaiRong(cd,cr);
//            hcn[i]=new HCNtest(cd,cr);
        }

//        System.out.println("Stt \t Chiều dài \t Chiều rộng \t Chu vi \t Diện tích" + "");
//        for(i =1;i<=n;i++)
//        {
//            System.out.println(i+"  \t\t " +hcn[i].getChieuDai()+"   " +
//                    "\t\t "+hcn[i].getChieuRong()+"   \t\t\t "+hcn[i].ChuviHCN()+"    " +
//                    " \t\t "+hcn[i].DientichHCN());
//        }
//
//        int Max=hcn[1].DientichHCN();
//        for(i=1;i<=n;i++)
//        {
//            if(hcn[i].DientichHCN()>Max)
//                Max=hcn[i].DientichHCN();
//        }
//        System.out.println("Hình chữ nhật có diện tích lớn là: "+Max);
//
//    }
}
}
